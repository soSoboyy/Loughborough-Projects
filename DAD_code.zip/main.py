from rentalSys import RentalShop,Customer,VIPCustomer

# main function
def main():
    shop = RentalShop()

    print("\nWelcome to Sohag's Car Rental System!")
    customerName = input("Please insert you name: ")
    print("\nHello," , customerName.title())
    customer_type = input("Would you like to be a regular or VIP customer? (regular/vip): ").strip().lower()
    customer = VIPCustomer() if customer_type == "vip" else Customer()
    print("\nYou have selected:", customer_type.title())

    while True:
        print("\nMenu:")
        print("1. View available cars")
        print("2. Rent a car")
        print("3. Return a car")
        print("4. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            customer.inquire_stock(shop)
        elif choice == "2":
            car_type = input("Enter car type (hatchback/sedan/suv): ").strip().lower()
            try:
                days = int(input("Enter number of days: "))
                customer.rent_car(shop, car_type, days)
            except ValueError:
                print("Invalid input for days. Please enter a number.")
        elif choice == "3":
            customer.return_car(shop)
        elif choice == "4":
            print("Thank you for using our service. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
