class RentalShop:
    def __init__(self):
        # Initialize the stock of cars
        self.stock = {
            "hatchback": 4,
            "sedan": 3,
            "suv": 3
        }
        self.prices = {
            "daily": {"hatchback": 30, "sedan": 50, "suv": 100},
            "weekly": {"hatchback": 25, "sedan": 40, "suv": 90}
        }

    def display_inventory(self):
        # Display current stock and prices
        print("\nAvailable Cars and Prices:")
        for car_type, count in self.stock.items():
            print(f"{car_type.capitalize()} - {count} available")
            print(f"  Less than 7 days: £{self.prices['daily'][car_type]} per day")
            print(f"  7 days or more: £{self.prices['weekly'][car_type]} per day")
        print("\nIf you have selected VIP customer, there is a special rate for you.")

    def rent_car(self, car_type, days):
        # Rent a car if stock is available
        if car_type not in self.stock:
            print("Invalid car type!")
            return None

        if self.stock[car_type] <= 0:
            print(f"Sorry, {car_type} cars are out of stock.")
            return None

        self.stock[car_type] -= 1
        rate = self.prices["weekly" if days >= 7 else "daily"][car_type]
        print(f"You have rented a {car_type.title()} car for {days} days,")
        print(f"you will be charged £{rate} per day. We hope you enjoy our service.")
        return rate

    def return_car(self, car_type, days, rate):
        # Return a car and calculate the bill
        if car_type in self.stock:
            self.stock[car_type] += 1
            total_cost = days * rate
            print("\nThank you for returning the car.")
            print(f"Rental Details:")
            print(f"  Car type: {car_type.capitalize()}")
            print(f"  Days rented: {days}")
            print(f"  Rate per day: £{rate}")
            print(f"  Total cost: £{total_cost}")
        else:
            print("Invalid car type!")


class Customer:
    def __init__(self):
    # Initialize customer attributes
        self.rented_car = None
        self.days_rented = 0
        self.rate = 0

    def inquire_stock(self, rental_shop):
    # View available inventory
        rental_shop.display_inventory()

    def rent_car(self, rental_shop, car_type, days):
        # Rent a car from the shop
        if self.rented_car:
            print("You already have a car rented. Please return it first.")
        else:
            rate = rental_shop.rent_car(car_type, days)
            if rate:
                self.rented_car = car_type
                self.days_rented = days
                self.rate = rate

    def return_car(self, rental_shop):
        # Return a rented car
        if not self.rented_car:
            print("You have no car to return.")
        else:
            rental_shop.return_car(self.rented_car, self.days_rented, self.rate)
            self.rented_car = None
            self.days_rented = 0
            self.rate = 0


class VIPCustomer(Customer):
    
# VIPCustomer inherits from Customer and offers special rates.
    
    def __init__(self):
        super().__init__()
        self.vip_rates = {
            "hatchback": 20,
            "sedan": 35,
            "suv": 80
        }

    def rent_car(self, rental_shop, car_type, days):
        
        # Rent a car from the shop with VIP rates.
        
        if self.rented_car:
            print("You already have a car rented. Please return it first.")
        else:
            if car_type not in self.vip_rates:
                print("Invalid car type!")
                return None
            if rental_shop.stock.get(car_type, 0) > 0:
                rental_shop.stock[car_type] -= 1
                self.rented_car = car_type
                self.days_rented = days
                self.rate = self.vip_rates[car_type]
                print(f"As a VIP customer, you have rented a {car_type}car for {days} days at a special rate of £{self.rate} per day.")
            else:
                print(f"Sorry, {car_type} cars are out of stock.")
